from django.apps import AppConfig


class CertificateProvidersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'certificate_providers'
