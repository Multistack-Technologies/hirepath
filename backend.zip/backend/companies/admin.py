from django.contrib import admin
from .models import Company

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ['name', 'industry', 'location', 'email', 'phone', 'created_by', 'created_at']
    list_filter = ['industry', 'created_at']
    search_fields = ['name', 'email', 'location', 'created_by__username']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['name']